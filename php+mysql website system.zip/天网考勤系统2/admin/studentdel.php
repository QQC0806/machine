﻿<?php
	include_once("../common/init.php");
	check_login();
	
	if ($_REQUEST["del"]) {
		$stuid=db_get_val("user",$_REQUEST["id"],"studentid");
		db_del($_REQUEST["del"],$_REQUEST["id"]);
		db_dela("user1","studentid='".$stuid."'");
		db_dela("committee","studentid='".$stuid."'");
		db_dela("achievement","stuid=".$_REQUEST["id"]);
		goBakMsg("删除成功");
	} else {
		die;
	}

?>