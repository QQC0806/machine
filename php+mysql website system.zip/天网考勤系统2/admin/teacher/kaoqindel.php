﻿<?php
	include_once("../../common/init.php");
	check_loginthe();
	
	if ($_REQUEST["del"]) {
		db_dela("kaoqinlist","begintime='".$_REQUEST["begintime"]."' and subjectid=".$_REQUEST["subjectid"]." and categoryid=".$_REQUEST["categoryid"]);
		goBakMsg("删除成功");
	} else {
		die;
	}

?>