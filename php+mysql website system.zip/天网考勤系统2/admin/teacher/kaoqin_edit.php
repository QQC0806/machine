<?php 
	include_once("../../common/init.php");
	check_loginthe();
	$categoryA = db_get_all("select * from semester");
	$categoryB = db_get_all("select * from subject where categoryid=".db_get_val("admin",$_SESSION['adminid'],"categoryid"));
	$user = db_get_all("select * from user where categoryid=".db_get_val("admin",$_SESSION['adminid'],"categoryid"));
	if ($_POST){
		$data = array();
		$row1 = db_get_row("select * from kaoqinlist where categoryid=". $_POST["categoryid"] ." and  subjectid=". $_POST["subjectid"] ."  and  begintime='". $_POST["begintime"]."'");

			if ($row1["id"]) {
				goBakMsg("考勤已添加");
				die;
			}
		for ($i=0; $i<count($_POST["stuid"]); $i++){
			$data["stuid"] = "'".$_POST["stuid"][$i]."'";
			$data["subjectid"] = "'".$_POST["subjectid"]."'";
			$data["semesterid"] = "'".$_POST["semesterid"]."'";
			$data["begintime"] = "'".$_POST["begintime"]."'";
			$data["categoryid"] = "'".$_POST["categoryid"]."'";
			$data["kaoqin"] = "'".$_POST["kaoqin"][$i]."'";
			$data["zuowei"] = "'".$_POST["zuowei"][$i]."'";
			db_add("kaoqinlist",$data);
		}
		goBakMsg("操作成功");
		
	}
?>
<?php include_once("base.php");?>
<body>
<table width="100%" border="0" cellpadding="0" cellspacing="0">
	<tr>
		<td width="17" rowspan="2" valign="top" bgcolor="#FFFFFF"></td>
		<td valign="top">
			<table width="100%" height="31" border="0" cellpadding="0" cellspacing="0">
				<tr bgcolor="#FFFFFF"><td height="31"><div class="title">添加考勤</div></td></tr>
			</table>
		</td>
		<td width="16" rowspan="2" bgcolor="#FFFFFF"></td>
	</tr>
	<tr>
	<td valign="top" bgcolor="#F7F8F9">
		<table width="100%" border="0" align="center" cellpadding="0" cellspacing="0">
			<tr><td colspan="4" height="10"></td></tr>
			<tr>
				<td width="1%">&nbsp;</td>
				<td width="96%">
					<table width="100%">
						<tr>
						  <td colspan="2">
							<form name="form1" method="post" action="?" onSubmit="return check()"  enctype="multipart/form-data">
									<input type="hidden" name="id" value="<?php echo $rs["id"];?>" />
                                    <input type="hidden" name="categoryid" value="<?php echo db_get_val("admin",$_SESSION['adminid'],"categoryid")?>" />
                                <table width="100%" class="cont">
                                    <tr>
                                      <td width="2%">&nbsp;</td>
                                        <td width="120" align="right">选择学期：</td>
                                      <td><select name="semesterid">
										  <?php foreach($categoryA as $row) {	?>
                                            <option value="<?php echo $row["id"];?>" <?php if($rs["semesterid"]==$row["id"]){echo ' selected="selected" ';}?>><?php echo $row["title"];?></option>
                                        <?php } ?>
                                      </select></td>
                                        <td width="2%">&nbsp;</td>
                                    </tr>
                                    
                                    <tr>
                                      <td width="2%">&nbsp;</td>
                                        <td width="120" align="right">选择科目：</td>
                                      <td><select name="subjectid">
										  <?php foreach($categoryB as $row) {	?>
                                            <option value="<?php echo $row["id"];?>" <?php if($rs["subjectid"]==$row["id"]){echo ' selected="selected" ';}?>><?php echo $row["title"];?></option>
                                        <?php } ?>
                                      </select></td>
                                        <td width="2%">&nbsp;</td>
                                    </tr>
                                   <tr>
                                          <td width="2%">&nbsp;</td>
                                            <td align="right">选择日期：</td>
                                          <td><script language="javascript" type="text/javascript" src="../../My97DatePicker/WdatePicker.js"></script>     
                                          		<input name="begintime" id="datepicker" type="text"   onClick="WdatePicker()" style="width:350px;" class="text" value="<?php echo $rs["begintime"];?>" required>
                                          </td>
                                            <td></td>
                                            <td width="2%">&nbsp;</td>
                                        </tr>
                                        
                                    <tr>
                                      <td width="2%">&nbsp;</td>
                                        <td width="120" align="right">学生考勤：</td>
                                      <td>

									<?php 
                                        foreach($user as $row) {
                                    ?><div style="float:left; margin:5px; width:231px; text-align:center; line-height:20px;">
                                    <input type="hidden" name="stuid[]" value="<?php echo $row["id"];?>"/><br />
                                    <?php echo $row["studentid"];?><br />
                                        <?php echo $row["stuname"];?><br />
                                        <select name="kaoqin[]">
                                            <option value="正常" <?php if($rs["kaoqin"]=="正常"){echo "selected";}?>>正常</option>
                                            <option value="旷课" <?php if($rs["kaoqin"]=="旷课"){echo "selected";}?>>旷课</option>
                                            <option value="请假" <?php if($rs["kaoqin"]=="请假"){echo "selected";}?>>请假</option>
                                            <option value="迟到" <?php if($rs["kaoqin"]=="迟到"){echo "selected";}?>>迟到</option></select>
                                            <br /><br /><input name="zuowei[]" type="text"  value="<?php echo $row["zuowei"];?>" placeholder="输入座位号"/>
                                       </div>
                                    <?php
                                    }
                                    ?> 
                                      </td>
                                        <td width="2%">&nbsp;</td>
                                    </tr>
                                        
                                       
                                    <tr>
                                        <td>&nbsp;</td>
                                        <td align="right"><input class="btn" type="submit" value="提交" /></td>
                                        <td>&nbsp;</td>
                                        <td>&nbsp;</td>
                                    </tr>
                                </table>
							</form>
						  </td>
							</tr>
						</table>
					</td>
					<td width="1%">&nbsp;</td>
				</tr>
				<tr><td height="20"></td></tr>
			</table>
		</td>
	</tr>
</table>
</body>
</html>