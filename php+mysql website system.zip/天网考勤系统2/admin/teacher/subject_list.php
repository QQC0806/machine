<?php 
	include_once("../../common/init.php");
	check_loginthe();
	$list = db_get_all("select * from subject where  categoryid=".db_get_val("admin",$_SESSION['adminid'],"categoryid")." order by id desc");
?>
<?php include_once("base.php");?>
<body>
<table width="100%" border="0" cellpadding="0" cellspacing="0">
	<tr>
		<td width="17" rowspan="2" valign="top" bgcolor="#FFFFFF"></td>
		<td valign="top">
			<table width="100%" height="31" border="0" cellpadding="0" cellspacing="0">
				<tr bgcolor="#FFFFFF"><td height="31"><div class="title">本班课程</div></td></tr>
			</table>
		</td>
		<td width="16" rowspan="2" bgcolor="#FFFFFF"></td>
	</tr>
	<tr>
	<td valign="top" bgcolor="#F7F8F9">
		<table width="100%" border="0" align="center" cellpadding="0" cellspacing="0">
			<tr><td colspan="4" height="10"></td></tr>
			<tr>
				<td width="1%">&nbsp;</td>
				<td width="96%">
					<table width="100%">
						<td colspan="2">
							<table width="100%"  class="cont tr_color">
								<tr>
									<th width="82">编号</th>
								  <th>科目名称</th>
								  <th width="150">上课时间</th>
								  <th width="150">上课地点</th>
							  </tr>
                                <?php
									foreach($list as $row){
								?>
								<tr align="center" class="d">
								  <td align="center"><?php echo $row['id'];?></td>
									<td align="left"><?php echo $row['title'];?></td>
									<td align="center"><?php echo $row['sktime'];?></td>
									<td><?php echo $row['skaddress'];?></td>
								</tr>
                                <?php } ?>
							</table>
						</td>
					</tr>
					</table>   
					</td>
					<td width="1%">&nbsp;</td>
				</tr>
				<tr><td height="20"></td></tr>
			</table>
		</td>
	</tr>
</table>
</body>
</html>