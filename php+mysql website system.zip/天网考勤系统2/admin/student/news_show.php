<?php 
	include_once("../../common/init.php");
	check_loginuser();
	$rs = array();
	if ($_REQUEST["id"]) {
		$rs = db_get_row("select * from content1 where id=". $_REQUEST["id"]);
	}
?>
<?php include_once("base.php");?>
<body>
<table width="100%" border="0" cellpadding="0" cellspacing="0">
	<tr>
		<td width="17" rowspan="2" valign="top" bgcolor="#FFFFFF"></td>
		<td valign="top">
			<table width="100%" height="31" border="0" cellpadding="0" cellspacing="0">
				<tr bgcolor="#FFFFFF"><td height="31"><div class="title">公告查看</div></td></tr>
			</table>
		</td>
		<td width="16" rowspan="2" bgcolor="#FFFFFF"></td>
	</tr>
	<tr>
	<td valign="top" bgcolor="#F7F8F9">
		<table width="100%" border="0" align="center" cellpadding="0" cellspacing="0">
			<tr><td colspan="4" height="10"></td></tr>
			<tr>
				<td width="1%">&nbsp;</td>
				<td width="96%">
					<table width="100%">
						<tr>
						  <td colspan="2">
								<form name="add" method="post" action="?" onSubmit="return checkadd()"  enctype="multipart/form-data">
									<input type="hidden" name="id" value="<?php echo $rs["id"];?>" />
									<input type="hidden" name="pid" value="2" />
                                    <table width="100%" class="cont">
                                        <tr>
                                          <td width="26">&nbsp;</td>
                                            <td width="202" align="right">公告名称：</td>
                                          <td width="1251"><?php echo $rs["title"];?></td>
                                            <td width="26" colspan="2"></td>
                                        </tr>
                                       
                                        <tr>
                                          <td>&nbsp;</td>
                                          <td align="right">详细内容：</td>
                                          <td>
											<?php echo $rs['content'];?>
                                          </td>
                                          <td></td>
                                        </tr>
                                        <tr>
                                            <td>&nbsp;</td>
                                            <td align="right"><?php echo $rs['addtime'];?></td>
                                            <td>&nbsp;</td>
                                            <td></td>
                                        </tr>
                                    </table>
							</form>
						  </td>
							</tr>
						</table>
					</td>
					<td width="1%">&nbsp;</td>
				</tr>
				<tr><td height="20"></td></tr>
			</table>
		</td>
	</tr>
</table>
</body>
</html>