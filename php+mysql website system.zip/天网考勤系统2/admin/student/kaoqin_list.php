<?php 
	include_once("../../common/init.php");
	check_loginuser();
	$categoryA = db_get_all("select * from semester");
	$where_sql = "1=1";
	if ($_REQUEST["semesterid"]) {
		$where_sql .= " and semesterid =". $_REQUEST["semesterid"] ." ";
	}
	if($_REQUEST["semesterid"])
	{
		//echo "select * from kaoqinlist where stuid=".$_SESSION['studentid']." and categoryid=".$_SESSION['categoryid']." and $where_sql order by id desc";
		//die;
		$kaoqin = db_get_all("select * from kaoqinlist where stuid=".$_SESSION['studentid']." and categoryid=".$_SESSION['categoryid']." and $where_sql order by id desc");
	}
	
?>
<?php include_once("base.php");?>
<body>
<table width="100%" border="0" cellpadding="0" cellspacing="0">
	<tr>
		<td width="17" rowspan="2" valign="top" bgcolor="#FFFFFF"></td>
		<td valign="top">
			<table width="100%" height="31" border="0" cellpadding="0" cellspacing="0">
				<tr bgcolor="#FFFFFF"><td height="31"><div class="title">考勤列表</div></td></tr>
			</table>
		</td>
		<td width="16" rowspan="2" bgcolor="#FFFFFF"></td>
	</tr>
	<tr>
	<td valign="top" bgcolor="#F7F8F9">
		<table width="100%" border="0" align="center" cellpadding="0" cellspacing="0">
			<tr><td colspan="4" height="10"></td></tr>
            <tr><td width="1%">&nbsp;</td><td width="96%">
            <table width="100%" class="cont">
			<tr>
            <td width="1%"></td>
            <td>
            <form id="pagerForm" action="?" method="get">
				<select name="semesterid">
					<option value="">-- 请选择 --</option>
					<?php
                    foreach($categoryA as $row) {
                    ?>
					<option value="<?php echo $row["id"];?>" <?php if($_REQUEST["semesterid"]==$row["id"]){echo ' selected="selected" ';}?>><?php echo $row["title"];?></option>
					<?php } ?>
				</select>
				<button type="submit"  id="chaxun" class="btn">查询</button>
			</form></td></tr></table>
            </td><td width="1%">&nbsp;</td></tr>
			<tr>
				<td width="1%">&nbsp;</td>
				<td width="96%">
					<table width="100%">
						<tr>
						  <td colspan="2">
							<form name="form1" method="post" action="?" enctype="multipart/form-data">
                                <table width="100%" class="cont">
                                        
                                        
                                        
                                    <tr>
                                      <td width="2%">&nbsp;</td>
                                        <td width="120" align="right">学生考勤：</td>
                                      <td>

									<?php 
                                        foreach($kaoqin as $row) {
                                    ?><div style="float:left; margin:5px; width:231px; text-align:center; line-height:20px;">
                                    <br />
                                    <?php echo db_get_val("subject",$row["subjectid"],"title")?><br />
                                       <br /><?php echo $row["kaoqin"];?>
                                       <br /><br />上课时间:<?php echo $row["begintime"];?>
                                       <br /><br />座位号:<?php echo $row["zuowei"];?>
                                       </div>
                                    <?php
                                    }
                                    ?> 
                                      </td>
                                        <td width="2%">&nbsp;</td>
                                    </tr>
                                        
                                       
                                    <tr>
                                        <td>&nbsp;</td>
                                        <td align="right"><input class="btn" type="button" value="打印" onClick="printpage()"/></td>
                                        <td>&nbsp;</td>
                                        <td>&nbsp;</td>
                                    </tr>
                                </table>
							</form>
						  </td>
							</tr>
						</table>   
					</td>
					<td width="1%">&nbsp;</td>
				</tr>
				<tr><td height="20"></td></tr>
			</table>
		</td>
	</tr>
</table>
<script language="javascript">
function printpage()
  {
  window.print()
  }
</script>
</body>
</html>