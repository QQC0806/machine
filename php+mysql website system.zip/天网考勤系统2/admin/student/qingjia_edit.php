<?php 
	include_once("../../common/init.php");
	check_loginuser();
	$rs = array();
	if ($_REQUEST["id"]) {
		$rs = db_get_row("select * from qingjia where id=". $_REQUEST["id"]);
	}
	if ($_POST){
		$data = array();
		$data["title"] = "'".$_POST["title"]."'";
		$data["content"] = "'".$_POST["content"]."'";
		$data["categoryid"] = "'".$_POST["categoryid"]."'";
		$data["studentid"] = "'".$_SESSION['studentid']."'";
		if ($_REQUEST["id"]) {
			db_mdf("qingjia",$data,$_REQUEST["id"]);
		} else {
			db_add("qingjia",$data);
		}
		urlMsg("提交成功", "qingjia_list.php");
		die;
	}
	
?>
<?php include_once("base.php");?>
	<script>
	function checkadd()
	{
	if (document.add.title.value=='')
	{
	alert('标题不能为空');
	document.add.title.focus;
	return false
	}
	var data = document.add.content.value;
	str = trim(data);//去除空格的
		if(data.length==0){
		alert("内容不能为空!");
		return false;
		}
	function trim(str){       
	str = str.replace(/^(\s|\u00A0)+/,'');      
	for(var i=str.length-1; i>=0; i--){           
		 if(/\S/.test(str.charAt(i))){              
			 str = str.substring(0, i+1);              
			 break;           
			 }      
		  }      
	  return str;  
	  }
	}
	</script>
<body>
<table width="100%" border="0" cellpadding="0" cellspacing="0">
	<tr>
		<td width="17" rowspan="2" valign="top" bgcolor="#FFFFFF"></td>
		<td valign="top">
			<table width="100%" height="31" border="0" cellpadding="0" cellspacing="0">
				<tr bgcolor="#FFFFFF"><td height="31"><div class="title">添加请假</div></td></tr>
			</table>
		</td>
		<td width="16" rowspan="2" bgcolor="#FFFFFF"></td>
	</tr>
	<tr>
	<td valign="top" bgcolor="#F7F8F9">
		<table width="100%" border="0" align="center" cellpadding="0" cellspacing="0">
			<tr><td colspan="4" height="10"></td></tr>
			<tr>
				<td width="1%">&nbsp;</td>
				<td width="96%">
					<table width="100%">
						<tr>
						  <td colspan="2">
								<form name="add" method="post" action="?" onSubmit="return checkadd()"  enctype="multipart/form-data">
									<input type="hidden" name="id" value="<?php echo $rs["id"];?>" />
                                    <input type="hidden" name="categoryid" value="<?php echo  db_get_val("user",$_SESSION['studentid'],"categoryid") ?>" />
                                    <table width="100%" class="cont">
                                        <tr>
                                          <td width="2%">&nbsp;</td>
                                            <td width="120" align="right"><span class="red">*</span> 标题：</td>
                                          <td><input name="title" type="text" class="text" style="width:350px;"  value="<?php echo $rs["title"];?>"></td>
                                            <td width="2%" colspan="2"></td>
                                        </tr>
                                       
                                        <tr>
                                          <td>&nbsp;</td>
                                          <td align="right">详细原因：</td>
                                          <td>
											<textarea name="content" id="content"  class="text" style="width:450px;"><?php echo $rs['content'];?></textarea>
                                          </td>
                                          <td></td>
                                        </tr>
                                        <tr>
                                            <td>&nbsp;</td>
                                            <td align="right"><input type="submit" class="btn" id="submitBtn" value="提交" ></td>
                                            <td>&nbsp;</td>
                                            <td></td>
                                        </tr>
                                    </table>
							</form>
						  </td>
							</tr>
						</table>
					</td>
					<td width="1%">&nbsp;</td>
				</tr>
				<tr><td height="20"></td></tr>
			</table>
		</td>
	</tr>
</table>
</body>
</html>