<?php 
	include_once("../common/init.php");
	check_login();
	$categoryA = db_get_all("select * from semester");
	$categoryB = db_get_all("select * from subject");
	$categoryC = db_get_all("select * from category");

	$where_sql = "1=1";
	if ($_REQUEST["semesterid"]) {
		$where_sql .= " and semesterid =". $_REQUEST["semesterid"] ." ";
	}
	if ($_REQUEST["categoryid"]) {
		$where_sql .= " and categoryid =". $_REQUEST["categoryid"] ." ";
	}
	if ($_REQUEST["subjectid"]) {
		$where_sql .= " and subjectid =". $_REQUEST["subjectid"] ." ";
	}
	if ($_REQUEST["begintime"]) {
		$where_sql .= " and begintime ='". $_REQUEST["begintime"] ."' ";
	}
	if($_REQUEST["semesterid"]&&$_REQUEST["subjectid"]&&$_REQUEST["begintime"]&&$_REQUEST["categoryid"])
	
	{
		//echo "select * from kaoqinlist where $where_sql order by id desc";
		//die;
		$kaoqin = db_get_all("select * from kaoqinlist where $where_sql order by id desc");
	}
	if ($_POST){
		$data = array();
		for ($i=0; $i<count($_POST["stuid"]); $i++){
			$data["kaoqin"] = "'".$_POST["kaoqin"][$i]."'";
			$data["zuowei"] = "'".$_POST["zuowei"][$i]."'";
			db_mdf("kaoqinlist",$data,$_POST["stuid"][$i]);
		}goBakMsg("操作成功");
		
	}
	
?>
<?php include_once("base.php");?>
<body>
<table width="100%" border="0" cellpadding="0" cellspacing="0">
	<tr>
		<td width="17" rowspan="2" valign="top" bgcolor="#FFFFFF"></td>
		<td valign="top">
			<table width="100%" height="31" border="0" cellpadding="0" cellspacing="0">
				<tr bgcolor="#FFFFFF"><td height="31"><div class="title">考勤列表</div></td></tr>
			</table>
		</td>
		<td width="16" rowspan="2" bgcolor="#FFFFFF"></td>
	</tr>
	<tr>
	<td valign="top" bgcolor="#F7F8F9">
		<table width="100%" border="0" align="center" cellpadding="0" cellspacing="0">
			<tr><td colspan="4" height="10"></td></tr>
            <tr><td width="1%">&nbsp;</td><td width="96%">
            <table width="100%" class="cont">
			<tr>
            <td width="1%"></td>
            <td>
            <form id="pagerForm" action="?" method="get">
				<select name="semesterid">
					<option value="">-- 请选择 --</option>
					<?php
                    foreach($categoryA as $row) {
                    ?>
					<option value="<?php echo $row["id"];?>" <?php if($_REQUEST["semesterid"]==$row["id"]){echo ' selected="selected" ';}?>><?php echo $row["title"];?></option>
					<?php } ?>
				</select>
                <select name="categoryid">
					<option value="">-- 请选择 --</option>
					<?php
                    foreach($categoryC as $row) {
                    ?>
					<option value="<?php echo $row["id"];?>" <?php if($_REQUEST["categoryid"]==$row["id"]){echo ' selected="selected" ';}?>><?php echo $row["title"];?></option>
					<?php } ?>
				</select>
                <select name="subjectid">
					<option value="">-- 请选择 --</option>
					<?php
                    foreach($categoryB as $row) {
                    ?>
					<option value="<?php echo $row["id"];?>" <?php if($_REQUEST["subjectid"]==$row["id"]){echo ' selected="selected" ';}?>><?php echo $row["title"];?></option>
					<?php } ?>
				</select>
                <script language="javascript" type="text/javascript" src="../My97DatePicker/WdatePicker.js"></script>     
					<input name="begintime" id="datepicker" type="text"   onClick="WdatePicker()" style="width:350px;" class="text" value="<?php echo $_REQUEST["begintime"];?>" required>
                
				<button type="submit"  id="chaxun" class="btn">查询</button>
			</form></td></tr></table>
            </td><td width="1%">&nbsp;</td></tr>
			<tr>
				<td width="1%">&nbsp;</td>
				<td width="96%">
					<table width="100%">
						<tr>
						  <td colspan="2">
							<form name="form1" method="post" action="?" enctype="multipart/form-data">
                                <table width="100%" class="cont">
                                        
                                        
                                        
                                    <tr>
                                      <td width="2%">&nbsp;</td>
                                        <td width="120" align="right">学生考勤：</td>
                                      <td>

									<?php 
                                        foreach($kaoqin as $row) {
                                    ?><div style="float:left; margin:5px; width:231px; text-align:center; line-height:20px;">
                                    <input type="hidden" name="stuid[]" value="<?php echo $row["id"];?>"/><br />
                                    <?php echo db_get_val("user",$row["stuid"],"studentid")?><br />
                                        <?php echo db_get_val("user",$row["stuid"],"stuname")?><br /><select name="kaoqin[]">
                                            <option value="正常" <?php if($row["kaoqin"]=="正常"){echo "selected";}?>>正常</option>
                                            <option value="旷课" <?php if($row["kaoqin"]=="旷课"){echo "selected";}?>>旷课</option>
                                            <option value="请假" <?php if($row["kaoqin"]=="请假"){echo "selected";}?>>请假</option>
                                            <option value="迟到" <?php if($row["kaoqin"]=="迟到"){echo "selected";}?>>迟到</option></select>
                                            <br /><br /><input name="zuowei[]" type="text"  value="<?php echo $row["zuowei"];?>" placeholder="输入座位号"/>
                                            </div>
                                    <?php
                                    }
                                    ?> 
                                      </td>
                                        <td width="2%">&nbsp;</td>
                                    </tr>
                                        
                                       
                                    <tr>
                                        <td>&nbsp;</td>
                                        <td align="right"><input class="btn" type="submit" value="修改" /> <input class="btn" type="button" value="打印" onClick="printpage()"/> </td>
                                        <td>&nbsp;&nbsp;&nbsp;<a href="kaoqindel.php?del=del&begintime=<?php echo $_REQUEST["begintime"];?>&subjectid=<?php echo $_REQUEST["subjectid"];?>&categoryid=<?php echo db_get_val("admin",$_SESSION['adminid'],"categoryid");?>">删除</a></td>
                                        <td>&nbsp;</td>
                                    </tr>
                                </table>
							</form>
						  </td>
							</tr>
						</table>   
					</td>
					<td width="1%">&nbsp;</td>
				</tr>
				<tr><td height="20"></td></tr>
			</table>
		</td>
	</tr>
</table>
<script language="javascript">
function printpage()
  {
  window.print()
  }
</script>
</body>
</html>