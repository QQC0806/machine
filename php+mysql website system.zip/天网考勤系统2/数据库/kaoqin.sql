﻿--
-- 数据库: `a420kaoqin`
--

-- --------------------------------------------------------

--
-- 表的结构 `admin`
--

CREATE TABLE IF NOT EXISTS `admin` (
  `id` int(4) NOT NULL AUTO_INCREMENT,
  `username` varchar(50) DEFAULT NULL,
  `password` varchar(50) DEFAULT NULL,
  `type` varchar(30) DEFAULT NULL,
  `categoryid` int(4) DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=11 ;

--
-- 转存表中的数据 `admin`
--

INSERT INTO `admin` (`id`, `username`, `password`, `type`, `categoryid`) VALUES
(1, 'admin', '21232f297a57a5a743894a0e4a801fc3', '管理员', 0),
(3, '111', '698d51a19d8a121ce581499d7b701668', '老师', 3),
(5, 'admin1', '21232f297a57a5a743894a0e4a801fc3', '老师', 2),
(10, '111111', '96e79218965eb72c92a549dd5a330112', '老师', 5),
(9, '222', '698d51a19d8a121ce581499d7b701668', '老师', 4);

-- --------------------------------------------------------

--
-- 表的结构 `category`
--

CREATE TABLE IF NOT EXISTS `category` (
  `id` int(6) NOT NULL AUTO_INCREMENT COMMENT 'id自然编号',
  `title` varchar(60) NOT NULL COMMENT '分类名称',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=7 ;

--
-- 转存表中的数据 `category`
--

INSERT INTO `category` (`id`, `title`) VALUES
(1, '大一一班d'),
(2, '大一二班'),
(5, '大一三班'),
(4, '大二一班'),
(3, '大二三班');

-- --------------------------------------------------------

--
-- 表的结构 `content1`
--

CREATE TABLE IF NOT EXISTS `content1` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `title` varchar(50) DEFAULT NULL COMMENT '标题',
  `content` text COMMENT '详细介绍',
  `addtime` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `apv` int(4) NOT NULL DEFAULT '0' COMMENT '点击',
  `categoryid` int(10) DEFAULT '0' COMMENT '所属班级',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=21 ;

--
-- 转存表中的数据 `content1`
--

INSERT INTO `content1` (`id`, `title`, `content`, `addtime`, `apv`, `categoryid`) VALUES
(15, '添加一要 ', '<p>添加一要 <br/>添加一要 <br/>添加一要 <br/>添加一要 <br/>添加一要 添加一要 <br/><br/></p>', '2017-10-24 16:34:06', 2, 0),
(7, '测试', '<p>压顶地<br/></p>', '2017-10-24 05:39:47', 27, 0),
(6, '测试一条数据', '<p>大规模夺<br/></p>', '2017-10-24 05:39:47', 21, 0),
(14, '测试一条数据', '<p>砝码夺<br/></p>', '2017-10-24 16:32:40', 1, 0),
(12, 'dfsdf圭', '<p>sdf<br/></p>', '2017-10-24 05:39:47', 0, 0),
(13, '压顶地aaaaaa砝码大', '<p>df<br/></p>', '2017-10-24 16:03:22', 3, 0),
(16, '大地震', '<p>地地<br/></p>', '2017-11-01 06:22:09', 1, 0),
(17, '添加一条测试', '添加一条测试', '2017-11-02 10:25:58', 0, 0),
(18, '大夺城', '大夺城大夺城大夺城大夺城大夺城大夺城大夺城', '2017-11-20 11:38:10', 0, 0),
(19, '压顶夺地', '压顶夺地压顶夺地压顶夺地压顶夺地压顶夺地压顶夺地', '2017-11-20 11:38:40', 0, 3),
(20, '添加一条本班公告', '添加一条本班公告', '2017-11-20 16:11:47', 0, 3);

-- --------------------------------------------------------

--
-- 表的结构 `kaoqinlist`
--

CREATE TABLE IF NOT EXISTS `kaoqinlist` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `stuid` int(11) DEFAULT '0' COMMENT '学生id',
  `subjectid` int(11) DEFAULT '0' COMMENT '科目id',
  `categoryid` int(11) DEFAULT '0' COMMENT '班级id',
  `begintime` date DEFAULT NULL COMMENT '上课时间',
  `kaoqin` varchar(20) DEFAULT '正常' COMMENT '考勤',
  `addtime` timestamp NULL DEFAULT CURRENT_TIMESTAMP COMMENT '添加时间',
  `semesterid` int(11) DEFAULT '0' COMMENT '学期',
  `zuowei` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=12 ;

--
-- 转存表中的数据 `kaoqinlist`
--

INSERT INTO `kaoqinlist` (`id`, `stuid`, `subjectid`, `categoryid`, `begintime`, `kaoqin`, `addtime`, `semesterid`, `zuowei`) VALUES
(1, 8, 3, 3, '2017-11-20', '正常', '2017-11-20 11:54:01', 1, NULL),
(2, 10, 3, 3, '2017-11-20', '旷课', '2017-11-20 11:54:01', 1, NULL),
(3, 11, 3, 3, '2017-11-20', '正常', '2017-11-20 11:54:01', 1, NULL),
(4, 14, 3, 3, '2017-11-20', '请假', '2017-11-20 11:54:01', 1, NULL),
(5, 15, 3, 3, '2017-11-20', '旷课', '2017-11-20 11:54:01', 1, NULL),
(6, 16, 3, 3, '2017-11-20', '正常', '2017-11-20 11:54:01', 1, NULL),
(7, 8, 3, 3, '2017-11-22', '旷课', '2017-11-22 10:44:36', 1, '25'),
(8, 10, 3, 3, '2017-11-22', '正常', '2017-11-22 10:44:36', 1, '34'),
(9, 11, 3, 3, '2017-11-22', '正常', '2017-11-22 10:44:36', 1, '66'),
(10, 15, 3, 3, '2017-11-22', '正常', '2017-11-22 10:44:36', 1, ''),
(11, 16, 3, 3, '2017-11-22', '正常', '2017-11-22 10:44:36', 1, '');

-- --------------------------------------------------------

--
-- 表的结构 `qingjia`
--

CREATE TABLE IF NOT EXISTS `qingjia` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `studentid` varchar(50) DEFAULT '0' COMMENT '学生id',
  `title` varchar(50) DEFAULT NULL COMMENT '原因',
  `content` varchar(250) DEFAULT NULL COMMENT '详细',
  `addtime` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `status` varchar(10) DEFAULT '未通过' COMMENT '状态',
  `categoryid` int(11) DEFAULT '0' COMMENT '班级id',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=20 ;

--
-- 转存表中的数据 `qingjia`
--

INSERT INTO `qingjia` (`id`, `studentid`, `title`, `content`, `addtime`, `status`, `categoryid`) VALUES
(2, '3', 'dfdfsd', '城厢地城地', '2017-10-24 13:48:18', '0', 0),
(3, '3', 'dfdsf', '大规模工', '2017-10-24 14:01:41', '0', 0),
(12, '9', 'dfdsf', '买过这个 ', '2017-10-24 16:47:59', '0', 0),
(13, '111111', 'dfdfsd', 'dfsdfdsf', '2017-11-02 04:25:05', '0', 0),
(14, '201102526325', '上课迟到', '上课迟到上课迟到上课迟到上课迟到', '2017-11-02 10:25:29', '0', 0),
(18, '8', '添加一条测试', 'dfdf', '2017-11-20 14:50:04', '通过', 3);

-- --------------------------------------------------------

--
-- 表的结构 `semester`
--

CREATE TABLE IF NOT EXISTS `semester` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=3 ;

--
-- 转存表中的数据 `semester`
--

INSERT INTO `semester` (`id`, `title`) VALUES
(1, '2017第一学期'),
(2, '2017第二学期');

-- --------------------------------------------------------

--
-- 表的结构 `subject`
--

CREATE TABLE IF NOT EXISTS `subject` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(50) DEFAULT NULL COMMENT '科目名称',
  `categoryid` int(11) DEFAULT '0' COMMENT '所属班级',
  `sktime` varchar(50) DEFAULT NULL COMMENT '上课时间',
  `skaddress` varchar(50) DEFAULT NULL COMMENT '上课地点',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=9 ;

--
-- 转存表中的数据 `subject`
--

INSERT INTO `subject` (`id`, `title`, `categoryid`, `sktime`, `skaddress`) VALUES
(1, '高数', 1, NULL, NULL),
(2, '英语', 2, NULL, NULL),
(3, '计算机', 3, NULL, NULL),
(4, '会计', 1, NULL, NULL),
(5, '经济学', 2, NULL, NULL),
(6, '政法1', 3, '10点-12点', '北楼多媒体'),
(7, '计算机科学', 3, '8点', '北楼教室'),
(8, '政法', 2, '12点', '北楼');

-- --------------------------------------------------------

--
-- 表的结构 `user`
--

CREATE TABLE IF NOT EXISTS `user` (
  `id` smallint(5) unsigned NOT NULL AUTO_INCREMENT,
  `studentid` varchar(64) NOT NULL COMMENT '学号',
  `stuname` varchar(50) NOT NULL COMMENT '姓名',
  `password` char(32) NOT NULL COMMENT '密码',
  `categoryid` int(11) NOT NULL DEFAULT '0',
  `dormroomid` int(11) DEFAULT '0' COMMENT '宿舍id',
  `addtime` timestamp NULL DEFAULT CURRENT_TIMESTAMP COMMENT '注册时间',
  `img` varchar(255) DEFAULT NULL COMMENT '头像',
  `sex` varchar(255) DEFAULT NULL COMMENT '性别',
  `status` int(2) NOT NULL DEFAULT '0' COMMENT '状态',
  PRIMARY KEY (`id`),
  UNIQUE KEY `account` (`studentid`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=17 ;

--
-- 转存表中的数据 `user`
--

INSERT INTO `user` (`id`, `studentid`, `stuname`, `password`, `categoryid`, `dormroomid`, `addtime`, `img`, `sex`, `status`) VALUES
(8, '343434', '李明', 'e1064a500b2640ff0a74439f1758c6aa', 3, 1, '2017-09-10 06:43:16', '4824792.jpg', '男', 0),
(10, 'afafaf', '李明1', '35abef9cacf725f2eb638651f4c90b2e', 3, 1, '2017-11-01 06:19:33', NULL, '男', 0),
(11, '201102526325', '李明1', 'c4ca4238a0b923820dcc509a6f75849b', 3, 1, '2017-11-02 06:58:00', '3422382.jpg', '男', 0),
(13, '2017856235', '12', 'c4ca4238a0b923820dcc509a6f75849b', 2, 1, '2017-11-02 10:24:52', '5982159.jpg', '女', 0),
(15, '1222222', '2222', 'e3ceb5881a0a1fdaad01296d7554868d', 3, 1, '2017-11-09 11:01:05', NULL, '男', 0),
(16, '34343', '李明1', 'aef5a7530aaa272bbaec34e49251b25a', 3, 1, '2017-11-09 11:10:26', '988045.jpg', '男', 0);

