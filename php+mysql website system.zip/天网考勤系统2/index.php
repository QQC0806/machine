<?php
	header('Location: admin/');
?>