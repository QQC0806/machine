<?php
	//配置信息
	$CONFIG = array(
		'db_host'=>"127.0.0.1",	//数据库地址
		'db_name'=>"a420kaoqin",		//数据库名成
		'db_user'=>"root",		//数据库用户名
		'db_pass'=>"root",		//数据库密码
		'url'=>"http://localhost/a420kaoqin",			//网站根目录地址
		'webname'=>"天网考勤系统",	//网站名称

	);
?>